import os
import json
from sentence_transformers import util, SentenceTransformer
import re
from openai import OpenAI
import openai

# Set this to the correct absolute or relative path of your database folder
root_dir = "/data/01_OBD-database"
llm_name = ['text-embedding-3-small', 'kforth/IfcMaterial2MP']


def getembedding(llm_name, string):
    openailist = ['text-embedding-3-large', 'text-embedding-ada-002', 'gpt-4o', 'text-embedding-3-small']
    if llm_name in openailist:
        openaikey = "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"
        client = OpenAI(api_key=openaikey)
        response = client.embeddings.create(input=string, model=llm_name)
        return response.data[0].embedding
    else:
        llm = SentenceTransformer(llm_name)
        embedding = llm.encode(string)
        return embedding.astype(float).tolist()

# Check if the root directory exists
if not os.path.exists(root_dir):
    print(f"Error: Directory '{root_dir}' does not exist!")
else:
    print(f"Searching in: {os.path.abspath(root_dir)}\n")

    # Walk through all subdirectories
    for dirpath, dirnames, filenames in os.walk(root_dir):
        print(f"Checking directory: {dirpath}")  # Debug: see where it's looking
        if "llm_categories.json" in filenames:
            file_path = os.path.join(dirpath, "llm_categories.json")
            print(f"\nFound: {file_path}")

            # Load and process the JSON
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                for i, item in enumerate(data['Material Categories']):
                    encodeditemGPT4o = getembedding(llm_name[0], item['name'])
                    encodeditemFinetuneBERT = getembedding(llm_name[1], item['name'])
                    tempdict = {llm_name[0]: encodeditemGPT4o, llm_name[1]: encodeditemFinetuneBERT}
                    data['Material Categories'][i].update(tempdict)
                print(f"Top-level keys: {list(data.keys())}\n")
                with open(f"{dirpath}\llm_embeddings.json", "w", encoding="utf-8") as f:
                    json.dump(data, f)
            except Exception as e:
                print(f"Failed to load {file_path}: {e}")
        elif "llm_materials.json" in filenames:
            file_path = os.path.join(dirpath, "llm_materials.json")
            print(f"\nFound: {file_path}")

            # Load and process the JSON
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                for i, item in enumerate(data['Material Options']):
                    encodeditemGPT4o = getembedding(llm_name[0], item['Name'])
                    encodeditemFinetuneBERT = getembedding(llm_name[1], item['Name'])
                    tempdict = {llm_name[0]: encodeditemGPT4o, llm_name[1]: encodeditemFinetuneBERT}
                    data['Material Options'][i].update(tempdict)
                print(f"Top-level keys: {list(data.keys())}\n")
                with open(f"{dirpath}\llm_embeddings.json", "w", encoding="utf-8") as f:
                    json.dump(data, f)
            except Exception as e:
                print(f"Failed to load {file_path}: {e}")
